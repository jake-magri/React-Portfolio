import Link from 'next/link';
import SlidingText from './SlidingText';
import styles from './AboutMe.module.css';

export default function AboutMe() {
  return (
    <div className={styles.container}>
      <div className={styles['about-cards']}>
        <div className={styles['about-text-card']}>

          <SlidingText
            direction="left"
            text={
              <>
                <p className={styles.eyebrow}>
                  AI Solutions Consultant • Workflow Automation • Product & Systems Design
                </p>

                <h1 className={styles['about-header']}>
                  Practical AI systems that reduce manual work and make operations easier to run.
                </h1>
              </>
            }
          />

          <section className={styles['about-summary']}>

            <p className={styles['about-p']}>
              I help teams find friction inside operational workflows and turn those bottlenecks into practical automation, reporting, and AI-enabled systems.
            </p>

            <p className={styles['about-p']}>
              My work sits between business requirements, product thinking, and technical delivery — translating operational pain into workflows, prototypes, requirements, and implementation plans teams can actually adopt.
            </p>

            <p className={styles['about-p']}>
              Recent work includes document-intelligence workflows for healthcare operations, retrieval systems over long-lived technical knowledge, natural-language reporting concepts, and AI-assisted operational automation.
            </p>

            <div className={styles.ctaRow}>
              <Link href="/portfolio" className={styles.primaryCta}>
                View Case Studies
              </Link>

              <Link href="/contact" className={styles.secondaryCta}>
                Discuss a Workflow
              </Link>
            </div>

            <h3 className={styles['specialization-header']}>
              Services
            </h3>

            <ul className={styles['specialization-list']}>

              <li>
                <strong>Workflow Review & Opportunity Mapping</strong><br />
                Identify manual work, bottlenecks, reporting gaps, and opportunities for automation.
              </li>

              <li>
                <strong>AI Workflow Automation</strong><br />
                Design AI-assisted processes with human review, business rules, and implementation paths.
              </li>

              <li>
                <strong>Document Intelligence Systems</strong><br />
                Convert PDFs, forms, notes, and operational documents into structured business workflows.
              </li>

              <li>
                <strong>Knowledge & Reporting Systems</strong><br />
                Make documentation and reporting easier to retrieve, understand, and act on.
              </li>

              <li>
                <strong>Product & Systems Design</strong><br />
                Translate workflow pain into requirements, prototypes, acceptance criteria, and delivery plans.
              </li>

            </ul>

          </section>

        </div>
      </div>
    </div>
  );
}